
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [balance, setBalance] = useState(null);
  const [services, setServices] = useState([]);

  useEffect(() => {
    axios.get('/api/balance').then(res => setBalance(res.data));
    axios.get('/api/services').then(res => setServices(res.data));
  }, []);

  return (
    <main style={{ padding: 20 }}>
      <h1>Panel FollowBack.xyz</h1>
      <h2>Saldo actual: {balance ? `${balance.balance} ${balance.currency}` : 'Cargando...'}</h2>
      <h3>Servicios disponibles:</h3>
      <ul>
        {services.map(service => (
          <li key={service.service}>
            {service.name} - {service.rate} USD ({service.min} a {service.max})
          </li>
        ))}
      </ul>
    </main>
  );
}
